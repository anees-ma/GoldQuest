
<form method="post" action="conv.php" target="_blank" enctype="multipart/form-data">
    <input type="hidden" name="inv_ord" value="20032020170428">
    <input type="submit" name="submit" value="submit">
</form>