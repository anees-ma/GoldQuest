<?php 
include '../config.php';
extract($_POST);

//variables declaration
$inv_ord=$_POST['inv_ord'];


$qry=mysqli_query($con,"select * from sales_rept where order_id='$inv_ord'");
$qryres=mysqli_fetch_assoc($qry);
$shp_id=$qryres['shop_id'];


$prd_id=$qryres['prd_id'];
$prd_idexp=explode(',',$prd_id);
$prdcont=count($prd_idexp)-1;

$ord_qty=$qryres['order_qty'];
$ord_qtyexp=explode(',',$ord_qty);

$orders_price=$qryres['orders_amnt'];
$orders_exp=explode(',',$orders_price);

$amnt=$qryres['amount'];
$ord_date=$qryres['date'];
$ord_time=$qryres['time'];


//selection of shop 
$qry2=mysqli_query($con,"select * from shops where shop_id='$shp_id'");
$qryres2=mysqli_fetch_assoc($qry2);
$shp_nme=$qryres2['shop_name'];
$shp_mobi=$qryres2['contact_mobile'];
$addr=$qryres2['address'];
$gst=$qryres2['shop_gst'];
$shp_pin=$qryres2['shop_pincode'];

//function
function pratap($r){
$i=0;
            for($i=0; $i < $prdcont; $i++){
                $prdid_inv=$prd_idexp[$i];
                
                //selection of prd name
                $invsel=mysqli_query($con,"select * from products_lists where prd_id='$prdid_inv'");
                $invselres=mysqli_fetch_assoc($invsel);
                $prd_nme[$i]=$invselres['prd_name'];
                $rt='';
                $rt .='<tr>
                    <td>'.$r.'</td>
                    <td>'.$ord_qtyexp[$i].'</td>
                    <td>'.$orders_exp[$i].'</td>
                    <td>.'($ord_qtyexp[$i] * $orders_exp[$i]).'</td>
                </tr>';
                
            }
            return $rt;
}

if(isset($submit)){
    $pdf='';
$pdf .= '
// You can put your HTML code here
<div class="inv_bx" id="tblCustomers">
    <div class="inv_img"><img src="https://farmocart.com/admin/images/formocart.jpg">
    <span>Order ID:&nbsp;'.$inv_ord.'</span>
    <span>Order Date:&nbsp;'.$ord_date.'&nbsp;'.$ord_time.'</span>
    </div>
    <br>
    <div class="addr_bx">
        <div class="fradr">
            From<br>
            Farmocart Pvt Ltd.</br>
            No. 27-27/A,Magadi main road,Vrishabhavathi Nagar<br>
            Kamakshipalya,Bangalore,Karnataka-560079.<br>
            GST NO:&nbsp;29AAECF0391G1ZN
        </div>
        <div class="fradr">
            To<br>
            Shop Name:&nbsp;'.$shp_nme.'<br>
            Shop Mobile:&nbsp;'.$shp_mobi.'<br>
            Address:&nbsp;'.$addr.'<br>
            Pincode:&nbsp;'.$shp_pin.'<br>
            GST NO:&nbsp;'.$gst.'<br>
        </div>
    </div>
    <br>
    <div class="prd_tbl">
        <table>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Price Per KG</th>
            <th>Total Price</th>';
            $pdf.= pratap(10);
            $pdf.='</table>
<div class="totbil">Total Bill:&nbsp;'.$amnt.'</div>
    </div>
    <div class="thnk">Thank You.</div>
</div>';

require('TCPDF/tcpdf.php');
$tcpdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set default monospaced font
$tcpdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set title of pdf
$tcpdf->SetTitle('Bill Collection Letter');

// set margins
$tcpdf->SetMargins(10, 10, 10, 10);
$tcpdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$tcpdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set header and footer in pdf
$tcpdf->setPrintHeader(false);
$tcpdf->setPrintFooter(false);
$tcpdf->setListIndentWidth(3);

// set auto page breaks
$tcpdf->SetAutoPageBreak(TRUE, 11);

// set image scale factor
$tcpdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

$tcpdf->AddPage();

$tcpdf->SetFont('times', '', 10.5);

$tcpdf->writeHTML($pdf, true, false, false, false, '');

//Close and output PDF document
$tcpdf->Output();
}
?>